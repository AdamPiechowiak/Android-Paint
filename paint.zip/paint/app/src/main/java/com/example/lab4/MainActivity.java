package com.example.lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btyellow = findViewById(R.id.btyellow);
        Button btred = findViewById(R.id.btred);
        Button btgreen = findViewById(R.id.btgreen);
        Button btblue = findViewById(R.id.btblue);
        Button btx = findViewById(R.id.btclear);
        PowierzchniaRysunku p = findViewById(R.id.powierzchnia_rysunku);

        btx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                p.wyczysc();
            }
        });

        btyellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                p.zmienKolor(Color.YELLOW);
            }
        });

        btred.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                p.zmienKolor(Color.RED);
            }
        });

        btgreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                p.zmienKolor(Color.GREEN);
            }
        });

        btblue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                p.zmienKolor(Color.BLUE);
            }
        });
    }
}